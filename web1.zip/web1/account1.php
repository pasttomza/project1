
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Open to shop tumbon</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>


<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/demo1.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,200,300,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Karla:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
		<!-- JavaScript includes -->



<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.validationEngine.js"></script>
<link rel="stylesheet" href="css/validationEngine.jquery.css" type="text/css" />


		<script src="js/ipresenter.packed.js"></script>
		<script>
			$(document).ready(function(){
				$('#ipresenter').iPresenter({
					timerPadding: -1,
					controlNav: true,
					controlNavThumbs: true,
					controlNavNextPrev: false
				});
			});
		</script>
		  <script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});

			function Inint_AJAX() {
           try { return new ActiveXObject("Msxml2.XMLHTTP");  } catch(e) {} //IE
           try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch(e) {} //IE
           try { return new XMLHttpRequest();          } catch(e) {} //Native Javascript
           alert("XMLHttpRequest not supported");
           return null;
        };

        function dochange(src, val) {
             var req = Inint_AJAX();
             req.onreadystatechange = function () { 
                  if (req.readyState==4) {
                       if (req.status==200) {
                            document.getElementById(src).innerHTML=req.responseText; //รับค่ากลับมา
                       } 
                  }
             };
             req.open("GET", "location.php?data="+src+"&val="+val); //สร้าง connection
             req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8"); // set Header
             req.send(null); //ส่งค่า
        }

        window.onLoad=dochange('province', -1); 


        function GetValue(){

        	if(document.registration_form.chk1.checked == false){
        		alert('กรุณายืนยันการเป็นเจ้าของ');
        		return false;
        	}
        }


        
		</script>


		    
</head>
<body>
	<!-- header-section-starts -->
	<div class="user-desc">
		<div class="container">
			<ul>
			

			</ul>
		</div>
		</div>
		<div class="header">
		<div class="header-top">
			<div class="container">
				<div class="logo">
					<a href="index1.html"><img src="images/logo01.png" alt="" /></a>
				</div>
				<div class="top-menu">
				   <span class="menu"> </span>
					<ul class="cl-effect-15">
						<li><a href="index1.html" data-hover="HOME">HOME</a></li>
						<li><a href=""data-hover="รายละเอียดร้านค้า">รายละเอียดร้านค้า</a></li>
						<li><a href="" data-hover="FIND SHOP">FIND SHOP</a></li>
						<li><a href="" data-hover="WEBBORD">WEBBORD</a></li>
						<li><a href="contact.html" data-hover="CONTACT">CONTACT</a></li>
					</ul>
				</div>
				<!--script-nav-->
				<script>
				$("span.menu").click(function(){
				$(".top-menu ul").slideToggle("slow" , function(){
				});
				});
				</script>
				<!--script-nav-->
				<div class="clearfix"></div>
			</div>
		</div>
		</div>
<!-- header-section-ends -->
<!-- content-section-starts -->
	<!-- start registration -->
	<div class="container">
		<div class="registration">
		 <div class="registration_left" >
		<h2><center>new user? </center><span><div><center> create An account </center></div></span></h2>
		<a href="#"><div class="reg_fb"><i>register</i><div class="clearfix"></div></div></a>
		<!-- [if IE] 
		    < link rel='stylesheet' type='text/css' href='ie.css'/>  
		 [endif] -->  
		  
		<!-- [if lt IE 7]>  
		    < link rel='stylesheet' type='text/css' href='ie6.css'/>  
		<! [endif] -->  


	<!---เช็คค่าว่างของฟอร็ม รีจิสเตอร็-->	

<div class="registration_form">
		 
		<!-- Form -->


			<form id="myForm" name="registration_form" action="register_save.php" enctype="multipart/form-data"  method="post" >
				
				<div>				
					<label>
					ชื่อ
						<input placeholder="name:" type="text" name="owner_name" tabindex="1" class="validate[required]">  
					</label>
				</div>
				<div>
					<label>
					นามสกุล 
						<input placeholder="last name:" type="text" name="owner_lastname" tabindex="2" class="validate[required]">
					</label>
				</div>
                <div>
					<label>
					เบอร์โทรศัพท์
						<input placeholder="telephone:" name="owner_tell" type="text" tabindex="3" class="validate[required,custom[telephone]] text-input">
					</label>
				</div>
                
				<div>
					<label>
					อีเมล์
						<input placeholder="email:" name="owner_email" type="text" tabindex="4" class="validate[required,custom[email]] text-input"> 
					</label>
				</div>
                <div>
					<label>
					ที่อยู่
						<input  placeholder="Address:" name="owner_address" type="text" tabindex="5" class="validate[required]">
					</label>
				</div>
                <div>
					<label>
						รูปบัตรประชาชน
						<input type=file name="owner_piccard"  name=galleryphoto size=55 class="validate[required]"> 
					</label>
				</div>

			<div>
                 <label> จังหวัด : </label>
                <span id="province" >
                    <select>
                        <option  value='0'>- เลือกจังหวัด -</option>
                    </select>
                </span>
            </div>
            <div>
               <label> อำเภอ : </label>
                <span id="amphur" >
                    <select>
                        <option  value='0'>- เลือกอำเภอ -</option>
                    </select>
                </span>
            </div>
            <div>
                <label> ตำบล : </label>
                <span id="district" >
                    <select>
                        <option value='0'>- เลือกตำบล -</option>
                    </select>
                   
                </span>
            </div>

				
				<div>
					<div>
					<label>เพศ </label>
					<span>ชาย: </span>
					<input class="validate[required] radio" type="radio"  name="owner_sex" value="ชาย">
					<span>หญิง: </span>
					<input class="validate[required] radio" type="radio" name="owner_sex" value="หญิง"/>
					
				</div>

				

                <div>
					<label>
						รูปโปรไฟล์ สมาชิก
						<input type=file name="owner_picself"  name=galleryphoto size=55 class="validate[required]"> 
					</label>
				</div>
                
                <div>

					<label>

					Username
						<input placeholder="Username:" name="owner_username" type="text" tabindex="1" class="validate[required,custom[noSpecialCaracters],length[0,20]]">
						<a href="#" class="menu" onClick="window.open('check_user.php', 'popup', 'height=150,width=360, left=450,top=150');">Check Username : Click Here.</a> 

						
					</label>
					
				
				</div>

				 <div>
				<label>
				password
					
					<input placeholder="Password" class="validate[required,length[6,11]] text-input" type="password" name="password" id="password"/>
				</label>
				</div>

				<div>
				<label>
				confirm password
					
					<input placeholder="confirm password" class="validate[required,confirm[password]] text-input" type="password" name="password2"/>
				</label>
				</div>
                
                	
				<div>
					<input type="submit" value="create an account" id="register-submit"  >
				</div>
			
			</form>
		
			</div>
		</div>
		<div class="clearfix"></div>
		</div>
		</div>
	</div>
</div>


   
</body>
</html>
