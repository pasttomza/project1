<?php 
include_once "Config.php";

$getId = $_GET['bank_id'];
$sql = "DELETE FROM bankaccount WHERE bank_id = '".$getId."'";
$query = mysqli_query($connection, $sql);

if(mysqli_affected_rows($connection)){
	header("location: BankAccount.php");
}
?>