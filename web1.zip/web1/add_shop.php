<?php 
ob_start();
session_start();


include_once 'Config.php';

$id = $_GET['id'];
$owner_id = $_GET['owner_id'];

$sql = "
		UPDATE owner SET 
		member_id  = '".$id."'
		WHERE owner_id = '".$owner_id."'
";
$query = mysqli_query($connection,$sql);


$strSQL = "
	SELECT p_id
	FROM product as a 
	LEFT JOIN owner as b ON b.owner_id = a.owner_id
	WHERE a.owner_id = '".$owner_id."'
";

$obj = mysqli_query($connection, $strSQL);
$row = mysqli_fetch_array($obj, MYSQLI_ASSOC);

$p_id = $row['p_id'];


if($query) {

	echo "
	<html>
	<head>
		<meta charset='utf-8'>
	</head>
	<body>
	</body>
	</html>
	<script>alert('สมัครสมาชิกเรียบร้อยแล้ว');window.location.href='my_shop.php?owner_id=$owner_id'

	</script>";
	//header("location: my_shop.php?owner_id=".$owner_id);

}
?>