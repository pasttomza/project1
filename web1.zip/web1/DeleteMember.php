<?php 
include_once "Config.php";

$getId = $_GET['member_id'];
$sql = "DELETE FROM member WHERE member_id = '".$getId."'";
$query = mysqli_query($connection, $sql);

if(mysqli_affected_rows($connection)){
	header("location: MemberIndex.php");
}
?>