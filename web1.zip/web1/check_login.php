<?php
	ob_start();
	session_start();

	require_once("Config.php");

	//$strusername = mysqli_real_escape_string($connection,$_POST['owner_username']);
	//$strpassword = mysqli_real_escape_string($connection,$_POST['owner_password']);


	if(!empty($_POST)) {

		$strusername = mysqli_real_escape_string($connection,$_POST['owner_username']);
		$strpassword = mysqli_real_escape_string($connection,$_POST['owner_password']);

		$ch_owner = "SELECT * FROM owner WHERE owner_username = '".$strusername."' and password = '".$strpassword."' ";
		$obj = mysqli_query($connection, $ch_owner);
		$rs = mysqli_fetch_array($obj, MYSQLI_ASSOC);

		if($rs) {
			
			$_SESSION["owner_id"] = $rs["owner_id"];
			$_SESSION["status"] = $rs["status"];
			$_SESSION["owner_username"] = $rs["owner_username"];
			$_SESSION["owner_name"] = $rs["owner_name"];
		

			session_write_close();

			if($rs["status"] == "owner"){
				header("location: openshop.php");		
			}

		} else {
			$ch_member = "SELECT * FROM member WHERE member_username = '".$strusername."' and member_password = '".$strpassword."' 
			AND member_check = 'active'
			";
			$obj_member = mysqli_query($connection, $ch_member);
			$rs_member = mysqli_fetch_array($obj_member, MYSQLI_ASSOC);

			if($rs_member) {

				$_SESSION["member_id"] = $rs_member["member_id"];
				$_SESSION["member_username"] = $rs_member["member_username"];
				
		

				session_write_close();

				
				header("location: Member_Shop.php");		
				
			}
		}

	}

/*	$strSQL = "SELECT * FROM owner WHERE owner_username = '".$strusername."' and password = '".$strpassword."' ";
	$objQuery = mysqli_query($connection,$strSQL) or die ("Error" . $strSQL);
	$objResult = mysqli_fetch_array($objQuery,MYSQLI_ASSOC);


	if($objResult){

		$_SESSION["owner_id"] = $objResult["owner_id"];
		$_SESSION["status"] = $objResult["status"];
		$_SESSION["owner_username"] = $objResult["owner_username"];
		$_SESSION["owner_name"] = $objResult["owner_name"];
		

		session_write_close();



		//if($objResult["owner_status"] == "admin"){
		//	header("location: admin_page.php");
		//}

		if($objResult["status"] == "owner"){
			header("location: openshop.php");		
		}

		//if($objResult["owner_status"] == "user"){
		//	header("location: user_page.php");
		//}
		
	} else {
		echo  "
			<html lange='en'>
				<head>
					<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
				</head>
				<body>
				</body>
			</html>
			<script>
				alert('Username หรือ Password ไม่ถูกต้อง');window.location.href='index1.html';
			</script>
		";
	}*/

	mysqli_close($connection);
?>