<?php 
include_once "Config.php";
$memberSend = "
	SELECT a.member_name,a.member_lastname,a.member_email,a.member_id,e.shop_name,b.owner_name
	FROM member as a
	LEFT JOIN owner as b ON b.owner_id = a.owner_id
	LEFT JOIN shop as e ON e.owner_id = b.owner_id
	ORDER BY a.member_id DESC

";
$query = $connection->query($memberSend);
$row = $query->fetch_assoc();


$sql = "
	UPDATE member SET
	member_check = 'active'
	WHERE member_id = '".$row['member_id']."'

";

$update = mysqli_query($connection, $sql);

if($update) {
	header("location: http://localhost:8888/web/index1.html");
}

?>