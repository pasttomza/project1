<?php

/*	$conn = new mysqli("localhost","root","root","project1");
	$conn->set_charset("UTF8");

	if($conn->connect_errno){
		echo $conn->connect_error;
		exit;
	} else {
		echo "..";
	}
	*/
$hostname_connection = "localhost";
$database_connection = "project1";
$username_connection = "root";
$password_connection = "root";
$connection = mysqli_connect($hostname_connection, $username_connection, $password_connection ,$database_connection);
$connection->query("SET NAMES UTF8");

?>