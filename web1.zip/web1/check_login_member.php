<?php
	session_start();

	require_once("Config.php");

	$strusername = mysqli_real_escape_string($connection,$_POST['member_username']);
	$strpassword = mysqli_real_escape_string($connection,$_POST['member_password']);

	//$strusername = $_POST['owner_username'];
	//$strpassword = $_POST['owner_password'];

	$strSQL = "SELECT * FROM member WHERE member_username = '".$strusername."' and member_password = '".$strpassword."' ";
	$objQuery = mysqli_query($connection,$strSQL) or die ("Error" . $strSQL);
	$objResult = mysqli_fetch_array($objQuery,MYSQLI_ASSOC);

	
	
	if($objResult){

		$_SESSION["member_id"] = $objResult["member_id"];
		$_SESSION["member_status"] = $objResult["member_status"];
		$_SESSION["member_username"] = $objResult["member_username"];
		$_SESSION["member_name"] = $objResult["member_name"];
		

		session_write_close();



		//if($objResult["owner_status"] == "admin"){
		//	header("location: admin_page.php");
		//}

		if($objResult["member_status"] == "member"){
			header("location: cartproduct.php");		
		}

		//if($objResult["owner_status"] == "user"){
		//	header("location: user_page.php");
		//}
		
	} else {
		echo  "
			<html lange='en'>
				<head>
					<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
				</head>
				<body>
				</body>
			</html>
			<script>
				alert('Username หรือ Password ไม่ถูกต้อง');window.location.href='products.php';
			</script>
		";
	}

	mysqli_close($connection);
?>