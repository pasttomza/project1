<?php 
include_once "Config.php";

$getId = $_GET['p_id'];
$sql = "DELETE FROM product WHERE p_id = '".$getId."'";
$query = mysqli_query($connection, $sql);

if(mysqli_affected_rows($connection)){
	header("location: backend.php");
}
?>