<?php 
include_once "Config.php";

$getId = $_GET['product_status_id'];
$sql = "DELETE FROM product_status WHERE product_status_id = '".$getId."'";
$query = mysqli_query($connection, $sql);

if(mysqli_affected_rows($connection)){
	header("location: ProductStatusIndex.php");
}
?>