<?php 
include_once "Config.php";

$getId = $_GET['product_type_id'];
$sql = "DELETE FROM product_type WHERE product_type_id = '".$getId."'";
$query = mysqli_query($connection, $sql);

if(mysqli_affected_rows($connection)){
	header("location: ProductTypeIndex.php");
}
?>