<?php
require_once("Config.php");

$show = "select * from owner where owner_username = '$owner_username'";
$result = mysql_query($show);
if(mysql_num_rows($result)>0){
    echo "$owner_username ไม่สามารถใช้ได้";
    echo exit();
} 
?>