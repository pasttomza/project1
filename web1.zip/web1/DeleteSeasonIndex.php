<?php 
include_once "Config.php";

$getId = $_GET['season_id'];
$sql = "DELETE FROM season WHERE season_id = '".$getId."'";
$query = mysqli_query($connection, $sql);

if(mysqli_affected_rows($connection)){
	header("location: ProductSeasonIndex.php");
}
?>