<?php 
include_once "Config.php";

$getId = $_GET['farmer_id'];
$sql = "DELETE FROM farmer WHERE farmer_id = '".$getId."'";
$query = mysqli_query($connection, $sql);

if(mysqli_affected_rows($connection)){
	header("location: ProfileFarmerIndex.php");
}
?>