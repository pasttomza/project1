<?php 
ob_start();
session_start();
include_once "Config.php";

/*$owner_id = $_SESSION['owner_id'];
$sql = "    
    SELECT a.shop_status 
    FROM shop as a 
    LEFT JOIN owner as b ON b.owner_id = a.owner_id
    WHERE a.owner_id = '$owner_id'
";
$query = $connection->query($_sql);
$row = $query->fetch_assoc();*/
             
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Gentellela Alela! | </title>

    <!-- Bootstrap -->
    <link href="gentelella-master/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="gentelella-master/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="gentelella-master/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="gentelella-master/vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="gentelella-master/vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="gentelella-master/vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="gentelella-master/vendors/starrr/dist/starrr.css" rel="stylesheet">

    <!-- Datatables -->
    <link href="gentelella-master/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="gentelella-master/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="gentelella-master/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="gentelella-master/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="gentelella-master/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="gentelella-master/production/css/custom.css" rel="stylesheet">
  </head>
  <body class="nav-md">
     
    

     <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.html" class="site_title"><i class="fa fa-shopping-bag"></i> <span>หลังร้านค้า</span></a>
            </div>

            <div class="clearfix"></div>
            <?php 
                  $sql = "SELECT * FROM owner as a LEFT JOIN owner as b ON b.owner_id = a.owner_id WHERE a.owner_id = '".$_SESSION['owner_id']."'";
                  $query = mysqli_query($connection, $sql);

              ?>
            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <?php 
                      $n = 1;
                      while($row = mysqli_fetch_array($query,MYSQLI_ASSOC)) {  ?>
                        <tr>
                        <td><?php echo $n++; ?></td>
                           <td><img src="images/<?php echo $row['owner_picself']; ?>" class="img-circle profile_img"  /> </td>
        
              </div>
               <?php } ?>
              <div class="profile_info">
                <span>ยินดีต้อนรับ</span>
                <h2><?php echo $_SESSION['owner_name']; ?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
              <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>gerneral</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-archive"></i> จัดการสินค้า <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu" style="display: none">
                      <li><a href="backend.php">รายการสินค้า</a>
                      </li> 
                      <li><a href="ProductTypeIndex.php">ประเภทสินค้าหลัก</a>
                      </li>
                      <li><a href="UnitIndex.php">หน่วยขายสินค้า</a>
                      </li>
                       <li><a href="ProductSeasonIndex.php">ฤดูสินค้า</a>
                      </li>
                       <li><a href="ProductStatusIndex.php">สถานะสินค้า</a>
                      </li>
                      <li><a href="ProfileFarmerIndex.php">เกษตรกร</a>
                      </li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-th-list"></i> จัดการรายการสั่งซื้อ <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu" style="display: none">
                      <li><a href="ListOrderIndex.php">รายการสั่งซื้อ</a>
                      </li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-money"></i> จัดการการเงิน <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu" style="display: none">
                      <li><a href="MoneyTranfer.php">รายการแจ้งโอนเงิน</a>
                      </li>
                      <li><a href="BankAccount.php">บันชีธนาคารร้าน</a>
                      </li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-user"></i> จัดการสมาชิก<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu" style="display: none">
                      <li><a href="MemberIndex.php">สมาชิกของร้านค้า</a>
                      </li>
                    </ul>
                  </li>
                  
                </ul>
              </div>             

            </div>
            <!-- /sidebar menu -->

           
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">

          <div class="nav_menu">
            <nav class="" role="navigation">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    เมนูสำหรับ <?php echo $_SESSION['owner_name']; ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                   <ul class="dropdown-menu dropdown-usermenu pull-right">
                    
                    <li><a href="products.php"><i class ="fa fa-reply pull-right"></i>กลับหน้าร้าน</a></li>
                    <li><a href="ProfileShop.php"><i class ="fa fa-gear    pull-right"></i>แก้ไขข้อมูลร้านค้า</a></li>
                    <li><a href="ProfileOwner.php"><i class = "fa fa-gear   pull-right"></i>แก้ไขข้อมูลผู้จัดการร้านค้า </a></li>
                    
                    <li><a href="logout.html"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                    </li>
                  </ul>
                </li>

              </ul>
            </nav>
          </div>

        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">

          <div class="">
            

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2> ข้อมูลสินค้า</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <form method="post" action="SaveProductForm.php" enctype="multipart/form-data" class="form-horizontal form-label-left" novalidate>

        

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> รูปสินค้า<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="product_picture" data-validate-length-range="6" data-validate-words="2" name="product_picture"  required="required" type="file">
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> รหัสสินค้า<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="product_id" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="product_id"  required="required" type="text">
                        </div>
                      </div>
                    
          
                  <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">ประเภทสินค้า<span class="required">*</span>
                        </label>
                         <div class="col-md-6 col-sm-6 col-xs-12">
                    <?php  
                    // ติดต่อฐานข้อมูล  
                    $link=mysql_connect("localhost","root","root") or die("error".mysql_error());  
                        mysql_select_db("project1",$link);  
                        mysql_query('SET NAMES UTF8');
                    ?>  
                    <select name="product_type" id="product_type">  
                   <?php  
                        $q="SELECT * FROM product_type as a LEFT JOIN owner as b ON b.owner_id = a.owner_id WHERE a.owner_id = '".$_SESSION['owner_id']."'"; 
                        $qr=mysql_query($q);  
                        while($rs=mysql_fetch_array($qr)){  
                    ?>
                  
                      <option value="<?=$rs['product_type_id']?>"><?=$rs['product_type_name']?></option>
                    <?php } ?>      
                    </select>  

                  </div>
                </div>

                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> ชื่อสินค้า<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="product_name" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="product_name"  required="required" type="text">
                        </div>
                      </div>


                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> รายละเอียดสินค้า<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <textarea id="product_description" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="product_description"  required="required" type="text"></textarea>
                        </div>
                      </div>

                   
                    <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">ฤดูสินค้า<span class="required">*</span>
                        </label>
                         <div class="col-md-6 col-sm-6 col-xs-12">
                   
                    <select name="season" id="season">  
                    <?php  
                        $q="SELECT * FROM season as a LEFT JOIN owner as b ON b.owner_id = a.owner_id WHERE a.owner_id = '".$_SESSION['owner_id']."'";  
                        $qr=mysql_query($q);  
                        while($rs=mysql_fetch_array($qr)){  
                    ?>                   
                      <option value="<?=$rs['season_name']?>">"<?=$rs['season_name']?>"</option>
                    <?php } ?>      
                    </select>  

                  </div>
                </div>


                       <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">ราคา<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="product_price" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="product_price"  required="required" type="text">
                        </div>
                      </div>

              
                    <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">หน่วย<span class="required">*</span>
                        </label>
                         <div class="col-md-6 col-sm-6 col-xs-12">
                    <?php  
                    // ติดต่อฐานข้อมูล  
                    $link=mysql_connect("localhost","root","root") or die("error".mysql_error());  
                        mysql_select_db("project1",$link);  
                        mysql_query('SET NAMES UTF8');
                    ?>  
                    <select name="unit" id="unit">  
                   <?php  
                        $q="SELECT * FROM unit as a LEFT JOIN owner as b ON b.owner_id = a.owner_id WHERE a.owner_id = '".$_SESSION['owner_id']."'"; 
                        $qr=mysql_query($q);  
                        while($rs=mysql_fetch_array($qr)){  
                    ?>
                  
                      <option value="<?=$rs['unit_id']?>"><?=$rs['unit_name']?></option>
                    <?php } ?>      
                    </select>  

                  </div>
                </div>

                 <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">รหัสเกษตรกร<span class="required">*</span>
                        </label>
                         <div class="col-md-6 col-sm-6 col-xs-12">
                     
                    <select name="farmer" id="farmer">  
                    <?php  
                        $q="SELECT * FROM farmer as a LEFT JOIN owner as b ON b.owner_id = a.owner_id WHERE a.owner_id = '".$_SESSION['owner_id']."'";  
                        $qr=mysql_query($q);  
                        while($rs=mysql_fetch_array($qr)){  
                    ?>
                      
                      <option value="<?=$rs['id_farmer']?>"><?=$rs['id_farmer']?></option>
                    <?php } ?>      
                    </select>  

                  </div>
                </div>

                <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">สถานะสินค้า<span class="required">*</span>
                        </label>
                         <div class="col-md-6 col-sm-6 col-xs-12">
                      
                    <select name="product_status" id="product_status">  
                    <?php  
                        $q="SELECT * FROM product_status as a LEFT JOIN owner as b ON b.owner_id = a.owner_id WHERE a.owner_id = '".$_SESSION['owner_id']."'";   
                        $qr=mysql_query($q);  
                        while($rs=mysql_fetch_array($qr)){  
                    ?>
                      
                      <option value="<?=$rs['product_status_name']?>"><?=$rs['product_status_name']?></option>
                    <?php } ?>      
                    </select>  

                  </div>
                </div>


                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <a href="backend.php" class="btn btn-danger"> ยกเลิก </a>
                          <button id="send" type="submit" class="btn btn-success">บันทึกรายการ</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            
            E-commerce - Bootstrap Admin Template by Pastta
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>


    <!-- jQuery -->
    <script src="gentelella-master/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="gentelella-master/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="gentelella-master/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="gentelella-master/vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="gentelella-master/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="gentelella-master/vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="gentelella-master/production/js/moment/moment.min.js"></script>
    <script src="gentelella-master/production/js/datepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="gentelella-master/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="gentelella-master/vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="gentelella-master/vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="gentelella-master/vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="gentelella-master/vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="gentelella-master/vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="gentelella-master/vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="gentelella-master/vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="gentelella-master/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="gentelella-master/vendors/starrr/dist/starrr.js"></script>

    <!-- Datatables -->
    <script src="gentelella-master/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="gentelella-master/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="gentelella-master/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="gentelella-master/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="gentelella-master/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="gentelella-master/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="gentelella-master/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="gentelella-master/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="gentelella-master/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="gentelella-master/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="gentelella-master/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="gentelella-master/vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="gentelella-master/vendors/jszip/dist/jszip.min.js"></script>
    <script src="gentelella-master/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="gentelella-master/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="gentelella-master/production/js/custom.js"></script> 
  </body>  
</html>
