<?php 
ob_start();
session_start();
include_once "Config.php";

		
		if(!empty($_POST)){
			if($_FILES['product_picture']['name'] !== ""){
				$name = $_FILES['product_picture']['name'];
				$tmp = $_FILES['product_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['product_picture']['name'])){
							$oldImg = $_FILES['product_picture']['name'];

							if(file_exists("images/$oldImg")){
								unlink("images/$oldImg");
							}
						}

						$product_picture = $name;
					}
				}
			}

			$product_id   = $_POST['product_id'];
			$product_type = $_POST['product_type'];		
			$product_name = $_POST['product_name'];
			$product_description = $_POST['product_description'];
			$product_price = $_POST['product_price'];
			$unit = $_POST['unit'];
			$season = $_POST['season'];
			$farmer = $_POST['farmer'];
			$product_status = $_POST['product_status'];
		}
		


		$sql = "INSERT INTO product(

		product_id,
		product_type,
		product_picture,
		product_name,
		product_description,
		product_price,
		unit,
		season,
		farmer,
		owner_id,
		product_status


		) 

		VALUES (


		'$product_id',
		'$product_type',
		'$product_picture',
		'$product_name',
		'$product_description',
		'$product_price',
		'$unit',
		'$season',
		'$farmer',
		'".$_SESSION['owner_id']."',
		'$product_status'


		)";



$query = $connection->query($sql);
if($query){
	header("location: backend.php");
}
?>



