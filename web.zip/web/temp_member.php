<?php 
ob_start();
session_start();



include_once "config.php";

$member_id = $_SESSION['member_id'];

$shop_id = $_GET['shop_id'];
$owner_id = $_GET['owner_id'];

$sql = "
	INSERT INTO temp_member(member_id,shop_id,owner_id) VALUES ('$member_id','$shop_id','$owner_id')
";

$query = mysqli_query($connection, $sql);

header("location: member_choose_shop.php");


?>