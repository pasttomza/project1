<?php 
ob_start();
session_start();
include_once "Config.php";

if(!empty($_POST)){
			if($_FILES['bank_picture']['name'] !== ""){
				$name = $_FILES['bank_picture']['name'];
				$tmp = $_FILES['bank_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['bank_picture']['name'])){
							$oldImg = $_FILES['bank_picture']['name'];

							if(file_exists("images/$oldImg")){
								unlink("images/$oldImg");
							}
						}

						$bank_picture = $name;
					}
				}
			}


		$bank_name     = $_POST['bank_name'];
		$bank_namebank = $_POST['bank_namebank'];
		$bank_lastname = $_POST['bank_lastname'];
		$bank_branch   = $_POST['bank_branch'];
		$bank_number   = $_POST['bank_number'];
		$bank_type     = $_POST['bank_type'];

}

		$sql = "INSERT INTO bankaccount(

		bank_picture,
		bank_name,
		bank_namebank,
		bank_lastname,
		bank_branch,
		bank_number,
		owner_id,
		bank_type

		) 

		VALUES (


		'$bank_picture',
		'$bank_name',
		'$bank_namebank',
		'$bank_lastname',
		'$bank_branch',
		'$bank_number',
		'".$_SESSION['owner_id']."',
		'$bank_type'

		)";



$query = $connection->query($sql);
if($query){
	header("location: BankAccount.php");
}
?>



