<?php
	ob_start();
	session_start();
	include_once "Config.php";


	if(!empty($_POST)){
			if($_FILES['member_picture']['name'] !== ""){
				$name = $_FILES['member_picture']['name'];
				$tmp = $_FILES['member_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['member_picture']['name'])){
							$oldImg = $_FILES['member_picture']['name'];

							if(file_exists("images/$oldImg")){
								unlink("images/$oldImg");
							}
						}

						$member_picture = $name;
					}
				}
			}




	$member_name           = $_POST['member_name'];
	$member_lastname       = $_POST['member_lastname'];
	$member_tell           = $_POST['member_tell'];
	$member_email          = $_POST['member_email'];
	$member_address	       = $_POST['member_address'];
	$member_sex		       = $_POST['member_sex'];
	$member_username	   = $_POST['member_username'];
	$member_password	   = $_POST['member_password'];
	$member_confirmpass	   = $_POST['member_confirmpass'];
	$owner_id = $_POST['owner_id'];
}


	
	
	$sql = "INSERT INTO member (

		member_picture,  
		member_name,
		member_lastname,
		member_tell,
		member_email,
		member_address,
		member_sex,
		member_username,
		member_password,
		owner_id,
		member_check,
		member_confirmpass
		
		
		
		
		) 

		VALUES (

		'$member_picture',
		'$member_name',
		'$member_lastname',
		'$member_tell',
		'$member_email',
		'$member_address',
		'$member_sex',
		'$member_username',
		'$member_password',
		'$owner_id',
		'block',
		'$member_confirmpass'
		
	
	
		
		)";

	
	
	$query = $connection->query($sql);
if($query):
	


?>



<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		var id = '#dialog';

		var maskHeight = $(document).height();
		var masWidth = $(window).width();

		$('#mask').css({'width':maskWidth,'height':maskHeight});
		$('#mask').fadeIn(1000);
		$('#mask').fadeTo("slow",0.8);

		var winH = $(window).height();
		var winW = $(window).width();

		$(id).css('top', winH/2-$(id).height()/2);
		$(id).css('left', winW/2-$(id).width()/2);

		$(id).fadeIn(2000);

		$('.window .close').click(function (e) {
			e.preventDefault();

			$('#mask').hide();
			$('.window').hide();
		});

		$('#mask').click(function () {
			$(this).hide();
			$('.window').hide();
		});
	});
</script>
<style type="text/css">
	.showBox {
		position: fixed;
		font-family: Arial, Helvetica, sans-serif;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		background: rgba(0,0,0,0.8);
		z-index: 99999;
		opacity: 0;
		-webkit-transition: opacity 400ms ease-in;
		-moz-transition: opacity 400ms ease-in;
		transition: opacity 400ms ease-in;
		pointer-events: none;
	}
	.showBox {
		padding-top: 30%;
		opacity: 1;
		pointer-events: auto;
	}
	.showBox > div {
		width: 400px;
		position: relative;
		margin: 10% auto;
		padding: 5px 20px 13px 20px;
		border-radius: 10px;
		background: #fff;
		background: -moz-linear-gradient(#fff, #999);
		background: -webkit-linear-gradient(#fff, #999);
		background: -o-linear-gradient(#fff, #999);
	}
	.close {
		background: #606061;
		color: #FFFFFF;
		line-height: 25px;
		position: absolute;
		right: -12px;
		text-align: center;
		top: -10px;
		width: 24px;
		text-decoration: none;
		font-weight: bold;
		-webkit-border-radius: 12px;
		-moz-border-radius: 12px;
		border-radius: 12px;
		-moz-box-shadow: 1px 1px 3px #000;
		-webkit-box-shadow: 1px 1px 3px #000;
		box-shadow: 1px 1px 3px #000;
	}
	.close:hover {
		background: #00d9ff;
	}
</style>
<style type="text/css">
	#morakot {
		margin: 0 auto;
		width: 460px;
		padding:  2em;
		background: #DCDDDF;
	}
	.ui-progress-bar {
		margin-top: 3em;
		margin-bottom: 3em;
	}
	.ui-progress span.ui-label {
		font-size: 1.2em;
		position: absolute;
		right: 0;
		line-height: 33px;
		padding-right: 12px;
		color: rgba(0,0,0,0.6);
		text-shadow: rgba(255,255,255, 0.45) 0 1px 0px;
		white-space: nowrap;
	}

	@-webkit-keyframes animate-stripes {
		from {
			background-position: 0 0;
		}
		to {
			background-position: 44px 0;
		}
	}

	.ui-progress-bar {
		position: relative;
		height: 35px;
		padding-right: 2px;
		background-color: #abb2bc;
		border-radius: 35px;
		-moz-border-radius: 35px;
		-webkit-border-radius: 35px;
		background: -webkit-gradient(linear, left bottom, left top, color-stop(0, #b6bcc6), color-stop(1, #9da5b0));
		background: -moz-linear-gradient(#9da5b0 0%, #b6bcc6 100%);
		-webkit-box-shadow: inset 0px 1px 2px 0px rgba(0, 0, 0, 0.5), 0px 1px 0px 0px #FFF;
		-moz-box-shadow: inset 0px 1px 2px 0px rgba(0, 0, 0, 0.5), 0px 1px 0px 0px #FFF;
		box-shadow: inset 0px 1px 2px 0px rgba(0, 0, 0, 0.5), 0px 1px 0px 0px #FFF;
	}

	.ui-progress {
		position: relative;
		display: block;
		overflow: hidden;
		height: 33px;
		-moz-border-radius: 35px;
		-webkit-border-radius: 35px;
		border-radius: 35px;
		-webkit-background-size: 44px 44px;
		background-color: #74d04c;
		background: -webkit-gradient(linear, 0 0, 44 44,
			color-stop(0.00, rgba(255,255,255,0.17)),
			color-stop(0.25, rgba(255,255,255,0.17)),
			color-stop(0.26, rgba(255,255,255,0)),
			color-stop(0.50, rgba(255,255,255,0)),
			color-stop(0.51, rgba(255,255,255,0.17)),
			color-stop(0.75, rgba(255,255,255,0.17)),
			color-stop(0.76, rgba(255,255,255,0)),
			color-stop(1.00, rgba(255,255,255,0))
		), -webkit-gradient(linear, left bottom, left top, color-stop(0, #74d04c), color-stop(1, #9bdd62));
		background: -moz-repeating-linear-gradient(top left -30deg,
			rgba(255,255,255,0.17),
			rgba(255,255,255,0.17) 15px,
			rgba(255,255,255,0) 15px,
			rgba(255,255,255,0) 30px
		), -moz-linear-gradient(#9bdd62 0%, #74d04 100%);
		-webkit-box-shadow: inset 0px 1px 0px 0px #dbf383, inset 0px -1px 1px #58c43a;
		-moz-box-shadow: inset 0px 1px 0px 0px #dbf383, inset 0px -1px 1px #58c43a;
		box-shadow: inset 0px 1px 0px 0px #dbf383, inset 0px -1px 1px #58c43a;
		border: 1px solid #4c8932;
		-webkit-animation: animate-stripes 2s linear infinite;
		
	}
</style>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

<script type="text/javascript">
	(function( $ ){
		$.fn.animateProgress = function(progress, callback) {
			return this.each(function() {
				$(this).animate({
					width: progress+'%'
				}, {
					duration: 2000,

					easing: 'swing',

					step: function( progress ){
						var labelEl = $('.ui-label', this),
							valueEl = $('.value', labelEl);

						if(Math.ceil(progress) < 20 && $('.ui-label', this).is(":visible")) {
							labelEl.hide();
						} else {
							if(labelEl.is(":hidden")) {
								labelEl.fadeIn();
							};
						}

						if(Math.ceil(progress) == 100) {
							labelEl.text('สำเร็จ');
							setTimeout(function() {
								labelEl.fadeOut();
							}, 1000);
						} else {
							valueEl.text(Math.ceil(progress) + '%');
						}
					},
					complete: function(scope, i, elem) {
						if(callback) {
							callback.call(this, i, elem);
						};
					}
				});
			});
		};
	})( jQuery );

	$(function() {
		$('#progress_bar .ui-progress .ui-label').hide();
		$('#progress_bar .ui-progress').css('width', '7%');

		$('#progress_bar .ui-progress').animateProgress(43, function() {
			$(this).animateProgress(50, function() {
				setTimeout(function() {
					$('#progress_bar .ui-progress').animateProgress(100, function() {
						$('#main_content').slideDown();
					});
				}, 2000);
			});

			$(this).animateProgress(65, function() {
				setTimeout(function() {
					$('#progress_bar .ui-progress').animateProgress(100, function() {
						$('#main_content').slideDown();
					});
				}, 2000);
			});

			$(this).animateProgress(78, function() {
				setTimeout(function() {
					$('#progress_bar .ui-progress').animateProgress(100, function() {
						$('#main_content').slideDown();
					});
				}, 2000);
			});
		});
	});
</script>


<html>
	<meta charset="utf-8">
	<body>
<?php 


/*$memberSend = "
	SELECT a.member_name,a.member_lastname,a.member_email,a.member_id,e.shop_name,b.owner_name
	FROM member as a
	LEFT JOIN owner as b ON b.owner_id = a.owner_id
	LEFT JOIN shop as e ON e.owner_id = b.owner_id
	WHERE a.member_name = '".$_POST['member_name']."'

";
$query = $connection->query($memberSend);
$row = $query->fetch_assoc();

$member_id = $row['member_id'];
$member_name = $row['member_name'];
$member_lastname = $row['member_lastname'];
$member_email = $row['member_email']; 
$shop_name = $row['shop_name'];
$owner_name = $row['owner_name'];*/
?>
<div id="openModal" class="showBox">
	<div id="morakot">
		<div style="text-align: center"> ขอบคุณที่ใช้บริการ ระบบกำลังส่งอีเมล์...กรุณารอสักครู่ </div>
			<div id="progress_bar" class="ui-progress-bar ui-container">
				<div class="ui-progress" style="width: 79%">
					<span class="ui-label" style="display:none;">กำลังส่ง... <b class="value">79%</b></span>
				</div>
			</div>

			<div class="content" id="main_content" style="display: none;">
				<a href="index1.html" title="Close" class="close">X</a>

				<?php 
				require("class.phpmailer.php");
				require("class.smtp.php");
				require("class.pop3.php");

				$mail = new PHPMailer();
				$mail->IsHTML(true);
				$mail->IsSMTP();
				$mail->Encoding = "quoted-printable";
				$mail->CharSet = "utf-8";
				$mail->SMTPAuth = true;
				$mail->SMTPSecure = "ssl";
				$mail->Host = "gator4050.hostgator.com";
				$mail->Port = 465;
				$mail->Username = "helpdesk@atomeii.com";
				$mail->Password = "help-1111";
				$mail->From = "$member_email";
				$mail->FromName = $member_name."   ".$member_lastname;
				$mail->Subject = "ระบบส่งเมล์ตอบกลับอัตโนมัติ";

				$txt = "
					<div style='text-align: center'>
					 <h2><strong>กรุณายืนยันเพื่อเข้าสู่ระบบ :  $shop_name </strong></h2> <br />
					 <h3>
					 <a href='http://localhost:8888/web/CheckMemberForOwner.php'>Click เพื่อยืนยันการเข้าสู่ระบบ</a>
					 </h3>
					</div>
				";
				$mail->Body = $txt;

				$mail->AddAddress($member_email);

				if(!$mail->Send()){
					echo "Mailer Error: " . $mail->ErrorInfo;
				} else {
					echo "คุณได้ส่ง E-mail เรียบร้อยแล้ว";
				}
				?>
			</div>
		</div>
	</div>
	</body>
</html>













<?php endif; ?>
