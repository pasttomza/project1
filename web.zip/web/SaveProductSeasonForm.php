<?php 
ob_start();
session_start();
include_once "Config.php";

$name = $_POST['season_name'];

$sql = "INSERT INTO season(season_name,owner_id) VALUES ('$name','".$_SESSION['owner_id']."')";

$query = $connection->query($sql);
if($query){
	header("location: ProductSeasonIndex.php");
}
?>