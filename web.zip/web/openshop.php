<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?
session_start();
if($_SESSION['logged_in'] != 1)
{
header("Location: login_incorrect.html");
}

include_once "Config.php";

$owner_id = $_SESSION['owner_id'];
$sql = "	
	SELECT a.shop_status 
	FROM shop as a 
	LEFT JOIN owner as b ON b.owner_id = a.owner_id
	WHERE a.owner_id = '$owner_id'
";
$query = $connection->query($sql);
$row = $query->fetch_assoc();
			 
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Open to shop tumbon</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/demo1.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,200,300,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Karla:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
		<!-- JavaScript includes -->
		<script src="js/ipresenter.packed.js"></script>
		<script>
			$(document).ready(function(){
				$('#ipresenter').iPresenter({
					timerPadding: -1,
					controlNav: true,
					controlNavThumbs: true,
					controlNavNextPrev: false
				});
			});
		</script>
		<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
</head>
<body>
	<!-- header-section-starts -->
	<div class="user-desc">
		<div class="container">
			<ul>
				<li> name : <?php echo $_SESSION["owner_name"];?></li>
				<li> username : <?php echo $_SESSION["owner_username"];?></li>
				<li> status : <?php echo $_SESSION["owner_status"];?></li>

				<li><i class=""></i><a href="logout.php">Logout</a></li>
				<?php if($row['shop_status'] == "true"){ ?>
				<li><i class=""></i><a href="products.php">เข้าสู่หน้าร้านค้า</a></li>
				<?php } else { ?>
				<li><a href="#">ยังไม่มีร้านค้า</a></li>
				<?php } ?>
			</ul>
		</div>
		</div>
		<div class="header">
		<div class="header-top">
			<div class="container">
				<div class="logo">
					<a href="index.html"><img src="images/logo01.png" alt="" /></a>
				</div>
				<div class="top-menu">
				   <span class="menu"> </span>
					<ul class="cl-effect-15">
						<li><a href="index1.html" data-hover="HOME">HOME</a></li>
						<li><a href=""data-hover="รายละเอียดร้านค้า">รายละเอียดร้านค้า</a></li>
						<li><a href="" data-hover="FIND SHOP">FIND SHOP</a></li>
						<li><a href="" data-hover="WEBBORD">WEBBORD</a></li>
						<li><a href="contact.html" data-hover="CONTACT">CONTACT</a></li>
					</ul>
				</div>
				<!--script-nav-->
				<script>
				$("span.menu").click(function(){
				$(".top-menu ul").slideToggle("slow" , function(){
				});
				});
				</script>
				<!--script-nav-->
				<div class="clearfix"></div>
			</div>
		</div>
		</div>
<!-- header-section-ends -->
<!-- content-section-starts -->
	
		<div class="coats sing-c">
			<h3 class="c-head">Wellcome to Open Shop tumbon</h3>
			<p>ยินดีต้อนรับสมาชิกทุกท่านค่ะ</p>
			<p>กรุณาคลิกเปิดร้านค้าตำบลค่ะ</p>
			<p>&nbsp</p>
			<p>V</p>
			<p>V</p>
			
			 <?php if($row['shop_status'] == "true"){ ?>
				<a href="#" onclick="return confirm('คุณได้เปิดร้านค้าไปแล้ว')">
					<img src="images/logo01.png" alt="" />
				</a>
			 <?php } else { ?>
				<a href="openshop1.php"><img src="images/logo01.png" alt="" /></a>	
			 <?php } ?>
			
		</div>

	</div>
	</div>
</div>
   <!-- content-section-ends -->

</body>
</html>


