 <?php
	ob_start();
	session_start();
	include_once "Config.php";


	if(!empty($_POST)){
			if($_FILES['shop_picture']['name'] !== ""){
				$name = $_FILES['shop_picture']['name'];
				$tmp = $_FILES['shop_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['shop_picture']['name'])){
							$oldImg = $_FILES['shop_picture']['name'];

							if(file_exists("images/$oldImg")){
								unlink("images/$oldImg");
							}
						}

						$shop_picture = $name;
					}
				}
			}


	$shop_name              = $_POST['shop_name'];
	$shop_description       = $_POST['shop_description'];
	$shop_telephone         = $_POST['shop_telephone'];
	$shop_email             = $_POST['shop_email'];
	$shop_address		    = $_POST['shop_address'];
	$owner_id				= $_SESSION['owner_id'];
	$shop_status 			= "true";

}
	
	$sql = "INSERT INTO shop (

		shop_picture,  
		shop_name,
		shop_description,
		shop_telephone,
		shop_email,
		owner_id,
		shop_status,
		shop_address
		
		) 

		VALUES (

		'$shop_picture',
		'$shop_name',
		'$shop_description',
		'$shop_telephone',
		'$shop_email',
		'".$_SESSION['owner_id']."',
		'$shop_status',
		'$shop_address'
	
		
		)";


	$query = $connection->query($sql);
	if($query){
		echo "
		<html lange='en'>
			<head>
			<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
			</head>
			<body>
			</body>
		</html>
		<script>alert('คุณได้เปิดร้านค้าเรียบร้อย');window.location.href='products.php';</script>";
	}


?>
