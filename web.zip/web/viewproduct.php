<?php 
ob_start();
session_start();
include_once "Config.php";
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Open to shop tumbon</title>
<link href="css/bootstrap1.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Custom Theme files -->
<link href="css/style1.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/component1.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,200,300,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Karla:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--webfont-->
<script src="js/jquery.min.js"></script>
<link rel="stylesheet" href="css/etalage.css">
<script src="js/jquery.etalage.min.js"></script>
<script>
			jQuery(document).ready(function($){

				$('#etalage').etalage({
					thumb_image_width: 300,
					thumb_image_height: 400,
					source_image_width: 800,
					source_image_height: 1000,
					show_hint: true,
					click_callback: function(image_anchor, instance_id){
						alert('Callback example:\nYou clicked on an image with the anchor: "'+image_anchor+'"\n(in Etalage instance: "'+instance_id+'")');
					}
				});

			});
		</script>
<link type="text/css" rel="stylesheet" href="css/easy-responsive-tabs.css" />
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });

        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script>
	    <script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
</head>
<body>
	<!-- header-section-starts -->
	<?php 
	$owner_id = $_SESSION['owner_id'];
	$sql = "
		SELECT a.shop_name 
		FROM shop as a 
		LEFT JOIN owner as b ON b.owner_id = a.owner_id
		WHERE a.owner_id = '$owner_id'
	";
	$query = $connection->query($sql);
	$row = $query->fetch_assoc();
	?>
	<div class="user-desc">
		<div class="container">
			<ul>
				<li><a class="user" href=""><?php echo $row['shop_name']; ?></a></li>
				
				
			</ul>
		</div>
		</div>
		<div class="header">
		<div class="header-top">
			<div class="container">
				<div class="logo">
					<a href="index.html"><img src="images/logo01.png" alt="" /></a>

				</div>
				<div class="top-menu">
				 <span class="menu"> </span>
					<ul class="cl-effect-15">
						<li><a href="products.php" data-hover="หน้าแรก">หน้าแรก</a></li>
						<li><a href="404.html" data-hover="วิธีการสั่งซื้อ">วิธีการสั่งซื้อ</a></li>
						<li><a href="active" data-hover="แจ้งชำระเงิน">แจ้งชำระเงิน</a></li>
						<li><a href="404.html" data-hover="เว็บบอร์ด">เว็บบอร์ด</a></li>
						<li><a href="contact.html" data-hover="ติดต่อเรา">ติดต่อเรา</a></li>
					</ul>
				</div>
				</div>
				<!--script-nav-->
				<script>
				$("span.menu").click(function(){
				$(".top-menu ul").slideToggle("slow" , function(){
				});
				});
				</script>
				<!--script-nav-->
				<div class="clearfix"></div>
			</div>
		</div>
		</div>
<!-- header-section-ends -->
	<!-- start content -->
	 			
	       
	<div class="single">
			<!-- start span1_of_1 -->
			<div class="left_content">
			<div class="span_1_of_left">
				<div class="grid images_3_of_2">
			 <?php 
                  $sql = "SELECT *,b.product_type_name FROM product as a 
                  LEFT JOIN product_type as b
                  ON b.product_type_id = a.product_type
                  LEFT JOIN owner as c 
                  ON c.owner_id = a.owner_id
                  WHERE a.owner_id = '".$_SESSION['owner_id']."'
                  AND a.p_id = '".$_GET['p_id']."'
                  ";
                  $query = $connection->query($sql);
                  $row = $query->fetch_assoc();

                  ?>
						<ul id="etalage">
						
							<li>	
							<img class="etalage_source_image" src="images/<?php echo $row['product_picture']; ?>"class="img-responsive" alt="" />
							
							</li>
							
						</ul>
						 <div class="clearfix"></div>		
				  </div>

			<!-- start span1_of_1 -->
			<div class="span1_of_1_des">
				  <div class="desc1">
					<h3>สินค้าเกษตรกรรม</h3>
					<p>ประเภทสินค้า : <?php echo $row['product_type_name']; ?></p>
					<p>ชื่อสินค้า : <?php echo $row['product_name']; ?></p>
					<p>รายละเอียดสินค้า :<?php echo $row['product_description']; ?></p>
					<p>ฤดูสินค้า :<?php echo $row['season']; ?></p>
					<p>ราคาสินค้า :<?php echo $row['product_price']; ?></p>
					<p>หน่วยสินค้า :<?php echo $row['unit']; ?></p>
					<p>สถานะสินค้า :<?php echo $row['product_status']; ?></p>
					<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
					<h5>ราคาสินค้า :<?php echo $row['product_price']; ?></h5>
					
						<div class="btn_form">
							<form>
							
								<input type="submit" value="add to cart" title="" />
								<input type="submit" value="back" title="" />
							</form>
						</div>
						
						<div class="clearfix"></div>
					</div>
					
			   	 </div>
			   	</div>
				
			   
			   	<!-- start tabs -->
			    <!--Horizontal Tab-->
        <div id="horizontalTab">
            
           
                
          
        </div>
					
		         	<!-- end tabs -->
			   	</div>
		
			 <div class="left_sidebar">
					
						
						<div class="single-nav">
			               
			              </div>
						 
						 
			    		</div>
					</div>
				</div>
					<!-- end sidebar -->
          	    <div class="clearfix"></div>
	       </div>	
		   </div>
	<!-- end content -->
	</div>
</div>
</div>	
<!-- content-section-ends -->	
<!-- contact-section-starts -->
	<div class="content-section">
		<div class="container">
			
			
			
		
	<!-- contact-section-ends -->
	<!-- footer-section-starts -->
	
		
			<div class="clearfix"></div>
		</div>
	</div>
	<!-- footer-section-ends -->
</body>
</html>