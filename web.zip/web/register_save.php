
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Open to shop tumbon</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/demo1.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,200,300,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Karla:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
		<!-- JavaScript includes -->
		<script src="js/ipresenter.packed.js"></script>
		<script>
			$(document).ready(function(){
				$('#ipresenter').iPresenter({
					timerPadding: -1,
					controlNav: true,
					controlNavThumbs: true,
					controlNavNextPrev: false
				});
			});
		</script>
		<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
</head>
<body>
	<!-- header-section-starts -->
	<div class="user-desc">
		<div class="container">
			<ul>
				<li><i class="user"></i><a href="index.html">Login</a></li>
			</ul>
		</div>
		</div>
		<div class="header">
		<div class="header-top">
			<div class="container">
				<div class="logo">
					<a href="index.html"><img src="images/logo01.png" alt="" /></a>
				</div>
				<div class="top-menu">
				   <span class="menu"> </span>
					<ul class="cl-effect-15">
						<li><a href="index1.html" data-hover="HOME">HOME</a></li>
						<li><a href=""data-hover="รายละเอียดร้านค้า">รายละเอียดร้านค้า</a></li>
						<li><a href="" data-hover="FIND SHOP">FIND SHOP</a></li>
						<li><a href="" data-hover="WEBBORD">WEBBORD</a></li>
						<li><a href="contact.html" data-hover="CONTACT">CONTACT</a></li>
					</ul>
				</div>
				<!--script-nav-->
				<script>
				$("span.menu").click(function(){
				$(".top-menu ul").slideToggle("slow" , function(){
				});
				});
				</script>
				<!--script-nav-->
				<div class="clearfix"></div>
			</div>
		</div>
		</div>
<!-- header-section-ends -->
<!-- content-section-starts -->
	
		<div class="coats sing-c">
			<h3 class="c-head">Wellcome to Open Shop tumbon</h3>
			<p>ขอบคุณที่สมัครสมาชิกกับ เว็บเราค่ะ</p>
			<p>รอเจ้าหน้าที่ตรวจสอบข้อมูล </p>
			<p>กรุณารออีเมล์ตอบกลับค่ะ</p>
			<p>เพื่อเปิดร้านค้ากับเว็บเราได้ค่ะ</p>
			<p>Please your wait Email send with you Go <a href="index1.html">here</a></p>
		</div>

	</div>
	</div>
</div>
   <?php
	
	session_start();
	include_once "Config.php";

	if(!empty($_POST)){
			if(($_FILES['owner_picself']['name'] !== "")&&($_FILES['owner_piccard']['name'] !== "")){
				$name = $_FILES['owner_picself']['name'];
				$tmp = $_FILES['owner_picself']['tmp_name'];
				$name = $_FILES['owner_piccard']['name'];
				$tmp = $_FILES['owner_piccard']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if((!empty($_FILES['owner_picself']['name']))&&(!empty($_FILES['owner_piccard']['name']))){
							$oldImg = $_FILES['owner_picself']['name'];
							$oldImg = $_FILES['owner_piccard']['name'];

							if(file_exists("images/$oldImg")){
								unlink("images/$oldImg");
							}
						}

						$owner_picself = $name;
						$owner_piccard = $name;
					}
				}
			}



	$owner_name            = $_POST['owner_name'];
	$owner_lastname        = $_POST['owner_lastname'];
	$owner_tell            = $_POST['owner_tell'];
	$owner_email		   = $_POST['owner_email'];
	$owner_address         = $_POST['owner_address'];
	$owner_sex			   = $_POST['owner_sex'];
	$owner_username        = $_POST['owner_username'];
	$password              = $_POST['password'];
	$password2             = $_POST['password2'];
	$province		       = $_POST['province'];
	$amphur 			   = $_POST['amphur'];
	$district		       = $_POST['district'];
	$status		   		   = "owner";

}

	$sql = "INSERT INTO owner (

		owner_name,
		owner_lastname,
		owner_tell,
		owner_email,
		owner_address,
		owner_piccard,
		owner_sex,
		owner_picself,
		owner_username,
		password,
		password2,
		province,
		amphur,
		owner_id,
		status,
		district
		
		) 

		VALUES (

		'$owner_name',
		'$owner_lastname',
		'$owner_tell',
		'$owner_email',
		'$owner_address',
		'$owner_piccard',
		'$owner_sex',
		'$owner_picself',
		'$owner_username',
		'$password',
		'$password2',
		'$province',
		'$amphur',
		
		'".$_SESSION['owner_id']."',
		'$status',
		'$district'
		)";


	$query = mysqli_query($connection, $sql);
	

	//if($query){
	//	echo "yes";
	//} else {
	//	echo "fail";
	//}


?>

</body>
</html>

