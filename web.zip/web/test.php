<?php 
include_once "Config.php";

	$sql = "select * from temp_member where shop_id = '".$_GET['shop_id']."'";

	if ($result=mysqli_query($connection,$sql))
  {
  // Return the number of rows in result set
  $rowcount=mysqli_num_rows($result);
  printf("Result set has %d rows.\n",$rowcount);
  // Free result set
  mysqli_free_result($result);
  }


?>