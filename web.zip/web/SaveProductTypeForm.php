<?php
ob_start();
session_start();
include_once "Config.php";

$name = $_POST['product_type_name'];

$sql = "INSERT INTO product_type(product_type_name,owner_id) VALUES ('$name','".$_SESSION['owner_id']."')";

$query = $connection->query($sql);
if($query){
	header("location: ProductTypeIndex.php");
}
?>