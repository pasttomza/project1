<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?
session_start();
if($_SESSION['logged_in'] != 1)
{
header("Location: login_incorrect.html");
}

include_once "Config.php";

$owner_id = $_SESSION['owner_id'];
$sql = "	
	SELECT a.shop_status 
	FROM shop as a 
	LEFT JOIN owner as b ON b.owner_id = a.owner_id
	WHERE a.owner_id = '$owner_id'
";
$query = $connection->query($sql);
$row = $query->fetch_assoc();
			 
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Open to shop tumbon</title>
<link href="css/bootstrap1.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style1.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/demo1.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,200,300,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Karla:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
		<!-- JavaScript includes -->
		<script src="js/ipresenter.packed.js"></script>
		<script>
			$(document).ready(function(){
				$('#ipresenter').iPresenter({
					timerPadding: -1,
					controlNav: true,
					controlNavThumbs: true,
					controlNavNextPrev: false
				});
			});
		</script>
		<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
</head>
<body>
	<!-- header-section-starts -->
	<div class="user-desc">
		<div class="container">
			<ul>
			<?php if($_SESSION['owner_id'] ==""): ?>
			<form name="Myform" method="post"  action="check_login_member.php"> 
			
				<li><a><i class="user"></i></a></li>
    			<li><input name="member_username" type="text" id="member_username" 
    			placeholder="username">
				<li><input name="member_password" type="password" id="member_password"
    			placeholder="password" required >
    			
    			<li><a><i class="button"></i></a></li>
    			<li><input type="submit" name="OK" value="  Login ">
    			  <input type="reset" name="OK2" value=" Clear "  >
    			</form>
    		<?php endif ?>

			</ul>
		</div>
		</div>
		<div class="header">
		<div class="header-top">
			<div class="container">
				<div class="logo">
					<a href="index.html"><img src="images/logo01.png" alt="" /></a>
				</div>
				<div class="top-menu">
				   <span class="menu"> </span>
					<ul class="cl-effect-15">
						<li><a href="products.php" data-hover="หน้าแรก">หน้าแรก</a></li>
						<li><a href="404.html" data-hover="วิธีการสั่งซื้อ">วิธีการสั่งซื้อ</a></li>
						<li><a href="active" data-hover="แจ้งชำระเงิน">แจ้งชำระเงิน</a></li>
						<li><a href="404.html" data-hover="เว็บบอร์ด">เว็บบอร์ด</a></li>
						<li><a href="contact.html" data-hover="ติดต่อเรา">ติดต่อเรา</a></li>
					</ul>
				</div>
				<!--script-nav-->
				<script>
				$("span.menu").click(function(){
				$(".top-menu ul").slideToggle("slow" , function(){
				});
				});
				</script>
				<!--script-nav-->
				<div class="clearfix"></div>
			</div>
		</div>
		</div>
<!-- header-section-ends -->
<!-- content-section-starts -->
	
		<div class="coats sing-c">
			<h3 class="c-head">Wellcome to new member</h3>
			<p>ยินดีต้อนรับสมาชิกทุกท่านค่ะ</p>
			<p>กรุณารออีเมล์ตอบกลับ</p>
			<p>จากทางเจ้าหน้าที่ค่ะ</p>
			<p>กรุณายืนยันสมาชิกจากอีเมล์ของท่านค่ะ</p>
			<p>&nbsp</p>
			
			
			
		</div>

	</div>
	</div>
</div>
   <!-- content-section-ends -->

</body>
</html>


