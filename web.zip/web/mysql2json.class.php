<?php 
class mysql2json{
 function getJSON($resultSet,$affectedRecords){
 $numberRows=0;
 $arrfieldName=array();
 $i=0;
 $json="";
	//print("Test");
 	while ($i < mysqli_num_fields($resultSet))  {
 		$meta = mysqli_fetch_field($resultSet, $i);
		if (!$meta) {
		}else{
		$arrfieldName[$i]=$meta->name;
		}
		$i++;
 	}
	 $i=0;
	  $json="[\n";
	while($row=mysqli_fetch_array($resultSet, MYSQL_NUM)) {
		$i++;
		$json.="{\n";
		for($r=0;$r < count($arrfieldName);$r++) {
			$json.=" \"$arrfieldName[$r]\" :	\"$row[$r]\"";
			if($r < count($arrfieldName)-1){
				$json.=",\n";
			}else{
				$json.="\n";
			}
		}
		 if($i!=$affectedRecords){
		 	$json.="\n},\n";
		 }else{
		 	$json.="\n}\n";
		 }	
	}
	$json.="\n]";
	
	return $json;
 }
}
?>
