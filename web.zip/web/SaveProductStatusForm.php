<?php 
ob_start();
session_start();
include_once "Config.php";

$name = $_POST['product_status_name'];

$sql = "INSERT INTO product_status(product_status_name,owner_id) VALUES ('$name','".$_SESSION['owner_id']."')";

$query = $connection->query($sql);
if($query){
	header("location: ProductStatusIndex.php");
}
?>