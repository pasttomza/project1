<?php 
ob_start();
session_start();
include_once "Config.php";

if(!empty($_POST)){
			if($_FILES['farmer_picture']['name'] !== ""){
				$name = $_FILES['farmer_picture']['name'];
				$tmp = $_FILES['farmer_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['farmer_picture']['name'])){
							$oldImg = $_FILES['farmer_picture']['name'];

							if(file_exists("images/$oldImg")){
								unlink("images/$oldImg");
							}
						}

						$farmer_picture = $name;
					}
				}
			}


		$id_farmer       = $_POST['id_farmer'];
		$farmer_name     = $_POST['farmer_name'];
		$farmer_lastname = $_POST['farmer_lastname'];
		$farmer_tell     = $_POST['farmer_tell'];
		$farmer_address  = $_POST['farmer_address'];
		$farmer_namefarm = $_POST['farmer_namefarm'];

}

		$sql = "INSERT INTO farmer(

		farmer_picture,
		id_farmer,
		farmer_name,
		farmer_lastname,
		farmer_tell,
		farmer_address,
		owner_id,
		farmer_namefarm

		) 

		VALUES (


		'$farmer_picture',
		'$id_farmer',
		'$farmer_name',
		'$farmer_lastname',
		'$farmer_tell',
		'$farmer_address',
		'".$_SESSION['owner_id']."',
		'$farmer_namefarm'

		)";



$query = $connection->query($sql);
if($query){
	header("location: ProfileFarmerIndex.php");
}
?>



