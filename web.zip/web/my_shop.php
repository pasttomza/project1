<?php 
ob_start();
session_start();
include_once 'Config.php';
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Open Shop Tumbon</title>
<link href="css/bootstrap1.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style1.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/component1.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,200,300,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Karla:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
  <script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
</head>
<body>
	<!-- header-section-starts -->
	<?php 
	$member_id = $_SESSION['member_id'];
	$sql = "
		SELECT member_name
		FROM member 
		WHERE member_id = '".$member_id."'
		
	";
	$query = $connection->query($sql);
	$row = $query->fetch_assoc();
	?>
	<div class="user-desc">
		<div class="container">
			
				<ul>
			
			 	<li><a href="#">ยินดีต้อนรับคุณ : <?php echo $row['member_name']; ?> </a></li>
    			
				<li><a href="logout.php"> ออกจากระบบ</a></li>
				<li><i class="pen"></i><a href="Member_Shop.php">กลับสู่หน้าหลัก Member</a></li>  

				

			</ul>


		</div>
		</div>



		<div class="header">
		<div class="header-top">
			<div class="container">
				<div class="logo">
					<a href="index.html"><img src="images/logo01.png" alt="" /></a>

				</div>
				<div class="top-menu">
				 <span class="menu"> </span>
					<ul class="cl-effect-15">
						<li><a href="products.php" data-hover="หน้าแรก">หน้าแรก</a></li>
						<li><a href="404.html" data-hover="วิธีการสั่งซื้อ">วิธีการสั่งซื้อ</a></li>
						<li><a href="active" data-hover="แจ้งชำระเงิน">แจ้งชำระเงิน</a></li>
						<li><a href="404.html" data-hover="เว็บบอร์ด">เว็บบอร์ด</a></li>
						<li><a href="contact.html" data-hover="ติดต่อเรา">ติดต่อเรา</a></li>
					</ul>
				</div>
				</div>
			
				<!--script-nav-->
				<script>
				$("span.menu").click(function(){
				$(".top-menu ul").slideToggle("slow" , function(){
				});
				});
				</script>
				<!--script-nav-->
				<div class="clearfix"></div>
			</div>
		</div>
		</div>
<!-- header-section-ends -->
<!-- content-section-starts -->

	<div class="container">	 
	   <div class="products-page">
			<div class="product">
				<div class="product-listy">
				<div class="latest-bis">
					<img src="images/f1.jpeg" class="img-responsive">
					<div class="offer">
						
					</div>
				</div>
				<?php 
				$id = $_GET['owner_id'];
				$sql = "SELECT * 
				FROM product_type as a 
				LEFT JOIN owner as b ON b.owner_id = a.owner_id 
				WHERE a.owner_id = '$id'";
				$query = mysqli_query($connection,$sql);
				?>
				
					<h3>ประเภท สินค้าเกษตรกรรม</h3>
					<ul class="product-list">
					<?php while($r = mysqli_fetch_array($query,MYSQLI_ASSOC)) {  ?>
						<li><a href=""><?php echo $r['product_type_name']; ?></a></li>
						
					<?php } ?>
					</ul>
				</div>
				
			</div>

			<?php 
			$getShop_id = $_SESSION['member_id'];
			$sqlShop = "select count(member_id) as count from temp_member where member_id =  '$getShop_id' ";
			$queryShop = mysqli_query($connection, $sqlShop);
			if($queryShop) {
				$objResult = mysqli_fetch_array($queryShop, MYSQLI_ASSOC);
				$inti = $objResult['count'];
			}
			
                 
			?>

			<div class="new-product">
				<div class="new-product-top">
					<ul class="product-top-list">
						<li><a href="index.html">Home</a>&nbsp;<span>&gt;</span></li>
						<li><span class="act">สินค้า มาใหม่</span>&nbsp;</li>
						<?php if($inti == 0): ?>
						<li>
						<a class="cbp-vm-icon cbp-vm-add" href="temp_member.php?shop_id=<?php echo $_GET['shop_id']; ?>&owner_id=<?php echo $_GET['owner_id']; ?>"> สมัครร้านนี้ </a> </li>
						<?php endif; ?>

					



					</ul>
					<p class="back"><a href="products.php">Back to Previous</a></p>
					<div class="clearfix"></div>
				</div>
				<div class="mens-toolbar">
                 <div class="sort">
               	  
	    		     </div>
		    	        <ul class="women_pagenation dc_paginationA dc_paginationA06">
					     <li><a href="#" class="previous">Page:</a></li>
					     <li class="active"><a href="#">1</a></li>
					     <li><a href="#">2</a></li>
				  	    </ul>
	               		 <div class="clearfix"></div>		
			        </div>
			        <div id="cbp-vm" class="cbp-vm-switcher cbp-vm-view-grid">
					
				
					<div class="clearfix"></div>

 				<?php 
                  $mysqls = "SELECT *,
                  b.product_type_name,
                  e.unit_name,
                  a.product_picture

                  FROM product as a 
                  LEFT JOIN product_type as b ON b.product_type_id = a.product_type
                  LEFT JOIN owner as c ON c.owner_id = a.owner_id
                  LEFT JOIN unit as e ON e.unit_id = a.unit 
                  LEFT JOIN member as d ON d.member_id = c.member_id
                  WHERE a.owner_id = '".$_GET['owner_id']."'
                  ";
                  $obj = mysqli_query($connection, $mysqls);

                  ?>
 
					<ul>
					<?php while($list = mysqli_fetch_array($obj,MYSQLI_ASSOC)) {  ?>
					  <li>
							<a class="cbp-vm-image" href="viewproduct.php?p_id=<?php echo $list['p_id']; ?>">
							 <div class="view view-first">
					   		  <div class="inner_content clearfix">
								<div class="product_image">
									<img src="images/<?php echo $list['product_picture']; ?>" width = '180px' height ='250px' class="img-responsive" alt=""/>
									<div class="mask">
			                       		<div class="info">Quick View</div>
					                  </div>
									<div class="product_container">
									   <div class="cart-left">
										<p class="title">รายละเอียดคลิ๊กที่รูปภาพ :<?php echo $list['product_name']; ?></p>
									   </div>
									  
									
									

									   <div class="clearfix"></div>
								     </div>		
								  </div>
			                     </div>
		                      </div>
		                    </a>
		                     <div class="cbp-vm-details"> รหัสสินค้า : <?php echo $list['product_id']; ?></div>

							 <div class="cbp-vm-details"> ประเภทสินค้า : <?php echo $list['product_type_name']; ?></div>
							 <div class="cbp-vm-details"> ราคาสินค้า : <?php echo $list['product_price']; ?></div>
							 <div class="cbp-vm-details"> หน่วยสินค้า: <?php echo $list['unit_name']; ?></div>
							  <div class="cbp-vm-details"> สถานะสินค้า: <?php echo $list['product_status']; ?></div>

							<a class="cbp-vm-icon cbp-vm-add" href='Member_cart.php'?p_id=$row[p_id]&act=add'>Add to cart</a>
						</li>
						<?php } ?>
						
						</li>
					</ul>
				</div>
				<script src="js/cbpViewModeSwitch.js" type="text/javascript"></script>
                <script src="js/classie.js" type="text/javascript"></script>
			</div>
			<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
   </div>
   <!-- content-section-ends -->	
   <!-- contact-section-starts -->
	<div class="content-section">
		<div class="container">
			
			
			
	<!-- contact-section-ends -->
	<!-- footer-section-starts -->
	
			
			<div class="clearfix"></div>
		</div>
	</div>
	<!-- footer-section-ends -->
</body>
</html>