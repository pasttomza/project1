<?php 
include_once "Config.php";

$name = $_POST['product_status_name'];

$sql = "INSERT INTO product_status(product_status_name) VALUES ('$name')";

$query = $connection->query($sql);
if($query){
	header("location: ProductStatusIndex.php");
}
?>