<?php
	ob_start();
	session_start();
	include_once "Config.php";


	if(!empty($_POST)){
			if($_FILES['member_picture']['name'] !== ""){
				$name = $_FILES['member_picture']['name'];
				$tmp = $_FILES['member_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['member_picture']['name'])){
							$oldImg = $_FILES['member_picture']['name'];

							if(file_exists("images/$oldImg")){
								unlink("images/$oldImg");
							}
						}

						$member_picture = $name;
					}
				}
			}




	$member_name           = $_POST['member_name'];
	$member_lastname       = $_POST['member_lastname'];
	$member_tell           = $_POST['member_tell'];
	$member_email          = $_POST['member_email'];
	$member_address	       = $_POST['member_address'];
	$member_sex		       = $_POST['member_sex'];
	$member_username	   = $_POST['member_username'];
	$member_password	   = $_POST['member_password'];
	$member_confirmpass	   = $_POST['member_confirmpass'];

}


	
	
	$sql = "INSERT INTO member (

		member_picture,  
		member_name,
		member_lastname,
		member_tell,
		member_email,
		member_address,
		member_sex,
		member_username,
		member_password,
		owner_id,
		member_check,
		member_confirmpass
		
		
		
		
		) 

		VALUES (

		'$member_picture',
		'$member_name',
		'$member_lastname',
		'$member_tell',
		'$member_email',
		'$member_address',
		'$member_sex',
		'$member_username',
		'$member_password',
		'".$_SESSION['owner_id']."',
		'block',
		'$member_confirmpass'
		
	
	
		
		)";


	
	$query = $connection->query($sql);
if($query){
	header("location: Register_Member_mail.php");
}


?>
