<?php 
ob_start();
session_start();
include_once 'Config.php';
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Open Shop Tumbon</title>
<link href="css/bootstrap1.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style1.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/component1.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,200,300,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Karla:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.validationEngine.js"></script>
<link rel="stylesheet" href="css/validationEngine.jquery.css" type="text/css" />
  <script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">







      jQuery(document).ready(function($) {
        $(".scroll").click(function(event){   
          event.preventDefault();
          $('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
        });
      });
    </script>
</head>
<body>
  <!-- header-section-starts -->
  <?php 
  $owner_id = $_SESSION['owner_id'];
  $sql = "
    SELECT a.shop_name 
    FROM shop as a 
    LEFT JOIN owner as b ON b.owner_id = a.owner_id
    WHERE a.owner_id = '$owner_id'
  ";
  $query = $connection->query($sql);
  $row = $query->fetch_assoc();
  ?>
  <div class="user-desc">
    <div class="container">
      <ul>
       
        
        </ul>
 
    </div>
    </div>



    <div class="header">
    <div class="header-top">
      <div class="container">
        <div class="logo">
          <a href="index.html"><img src="images/logo01.png" alt="" /></a>

        </div>
        <div class="top-menu">
         <span class="menu"> </span>
          <ul class="cl-effect-15">
            <li><a href="index1.html" data-hover="หน้าแรก">หน้าแรก</a></li>
            <li><a href="404.html" data-hover="วิธีการสั่งซื้อ">วิธีการสั่งซื้อ</a></li>
            <li><a href="active" data-hover="แจ้งชำระเงิน">แจ้งชำระเงิน</a></li>
            <li><a href="404.html" data-hover="เว็บบอร์ด">เว็บบอร์ด</a></li>
            <li><a href="contact.html" data-hover="ติดต่อเรา">ติดต่อเรา</a></li>
          </ul>
        </div>
        </div>
      
        <!--script-nav-->
        <script>
        $("span.menu").click(function(){
        $(".top-menu ul").slideToggle("slow" , function(){
        });
        });
        </script>
        <!--script-nav-->
        <div class="clearfix"></div>
      </div>
    </div>
    </div>
<!-- header-section-ends -->
<!-- content-section-starts -->

  <div class="container">  
    
    
      <div class="new-product1">
        <div class="new-product-top">

    <div class="registration">
     <div class="registration_left" >
    <h2><center>Register Member</center></h2>
    <a href="#"><div class="reg_fb"><i>register</i><div class="clearfix"></div></div></a>
    <!-- [if IE] 
        < link rel='stylesheet' type='text/css' href='ie.css'/>  
     [endif] -->  
      
    <!-- [if lt IE 7]>  
        < link rel='stylesheet' type='text/css' href='ie6.css'/>  
    <! [endif] -->  


  <!---เช็คค่าว่างของฟอร็ม รีจิสเตอร็-->  

<div class="registration_form">
     
    <!-- Form -->

         
<form id="myForm" name="registration_form" action="RegisterToMe_save.php" enctype="multipart/form-data" method="post" >

        <div>
          <label>
            รูปโปรไฟล์ สมาชิก
            <input id= "member_picture" type=file name="member_picture" size=55 class="validate[required]"> 
          </label>
        </div>
        <div>
       
      

        
        <div>       
          <label>
          ชื่อ
            <input placeholder="name: "type="text" name="member_name" tabindex="1" class="validate[required]">
          </label>
        </div>
        <div>
          <label>
          นามสกุล 
            <input placeholder="last name:" type="text" name="member_lastname" tabindex="2" class="validate[required]">
          </label>
        </div>
                <div>
          <label>
          เบอร์โทรศัพท์
            <input placeholder="telephone:" name="member_tell" type="text" tabindex="3" class="validate[required,custom[telephone]] text-input">
          </label>
        </div>
                
        <div>
          <label>
          อีเมล์
            <input placeholder="email:" name="member_email" type="text" tabindex="4" class="validate[required,custom[email]] text-input"> 
          </label>
        </div>
                <div>
          <label>
          ที่อยู่
            <input  placeholder="Address:" name="member_address" type="text" tabindex="5" class="validate[required]">
          </label>
        </div>
       
   
          <div>
          <label>เพศ </label>
          <span>ชาย: </span>
          <input class="validate[required] radio" type="radio"  name="member_sex" value="ชาย">
          <span>หญิง: </span>
          <input class="validate[required] radio" type="radio" name="member_sex" value="หญิง"/>
          
        </div>
               
        <div>
          <label>
          Username
            <input placeholder="Username:" name="member_username" type="text" tabindex="1" class="validate[required,custom[noSpecialCaracters],length[0,20]]">
          </label>
        </div>

         <div>
        <label>
        password
          
          <input placeholder="Password" class="validate[required,length[6,11]] text-input" type="password" name="member_password" id="password"/>
        </label>
        </div>

        <div>
        <label>
        confirm password
          
          <input placeholder="confirm password" class="validate[required,confirm[password]] text-input" type="password" name="member_confirmpass"/>
        </label>
        </div>
      
                
        <div>
          <input type="submit" value="สมัครสมาชิก" id="register-submit"  >
        </div>
      
      </form>


</div>


</body>
</html>