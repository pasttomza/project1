<?php 
ob_start();
session_start();
include_once "Config.php";

$name = $_POST['unit_name'];

$sql = "INSERT INTO unit(unit_name,owner_id) VALUES ('$name','".$_SESSION['owner_id']."')";

$query = $connection->query($sql);
if($query){
	header("location: UnitIndex.php");
}
?>