        
          
           <div class="navbar nav_title" style="border: 0;">
              <a href="index.php?r=Admin/EmployeeIndex" class="site_title"><i class="fa fa-windows"></i> <span> BIC ERP </span></a>
            </div>

            <div class="clearfix"></div>
            
            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img src="" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>ยินดีต้อนรับ</span>
                <h2>ชื่อ หกดหกดหกดหกด</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />
            

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu" style="margin-top: 39%">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-home"></i> หน้าหลัก <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu" style="display: none">
                      <li><a href="index.php?r=Admin/EmployeeIndex"> ผู้ใช้งานระบบ</a>
                      </li>
                      <li><a href="index.php?r=Admin/LoginTime">จำนวน Login</a>
                      </li>
                      
                      <li><a href="index.php?r=Admin/GroupIndex">โครงสร้างผ่าย/แผนก</a>
                      </li>
                    </ul>
                  </li>
                 
                  <li><a><i class="fa fa-desktop"></i> เก็บข้อมูลระบบ <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu" style="display: none">
                      <li><a href="index.php?r=Admin/_BICAdmin">ระบบ BIC Admin</a>
                      </li>
                      <li><a href="index.php?r=Admin/DataSaleMobile">Sale Order Mobile</a>
                      </li>
                      <li><a href="index.php?r=Admin/_BICHelpDesk">ระบบ BIC Help Desk</a>
                      </li>
                      <li><a href="index.php?r=Admin/_BICSaleOrder">ระบบ BIC Sale Order</a>
                      </li>
                      <li><a href="index.php?r=Admin/_BICDocument">ระบบ BIC Document Control</a>
                      </li>
                      <li><a href="index.php?r=Admin/_BICWarehouse">ระบบ BIC Transport</a>
                      </li>
                      <li><a href="index.php?r=Admin/_BICGallery">ระบบ BIC Gallery</a>
                      </li>
                      <li><a href="index.php?r=Admin/_BICProfile">ระบบ BIC Profile</a>
                      </li>
                      <li><a href="index.php?r=Admin/_BICStock">ระบบ BIC Inventory</a>
                      </li>
                    </ul>
                  </li>
                
                </ul>
              </div>
            </div>
            <!-- /sidebar menu -->

       