<?php 

include_once "Config.php";



		$ppid       = $_POST['product_id'];
		$ptype      = $_POST['product_type'];		
		$pname      = $_POST['product_name'];
		$pseason    = $_POST['season'];
		$pdes       = $_POST['product_description'];
		$pprice     = $_POST['product_price'];
		$ppunit     = $_POST['unit'];
		$pfarmer    = $_POST['farmer'];
		$pstatus    = $_POST['product_status'];

		$id        = $_POST['p_id'];
	//}

$sql = "
		UPDATE product SET 
			product_id              = '".$ppid."',
			product_type            = '".$ptype."',			
			product_name            = '".$pname."',
			season                  = '".$pseason."',
			product_description     = '".$pdes."',
			product_price           = '".$pprice."',
			unit                    = '".$ppunit."',
			farmer                  = '".$pfarmer."',
			product_status          = '".$pstatus."'
		
		WHERE p_id = '".$id."'
";
$query = mysqli_query($connection,$sql);


		if($_FILES['product_picture']['name'] != ""){
				$name = $_FILES['product_picture']['name'];
				$tmp = $_FILES['product_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['product_picture']['name'])){
							$oldImg = $_FILES['product_picture']['name'];

							if(file_exists("images/$oldImg")){
								@unlink("images/$oldImg");
							}
						}
					

						$picture = $name;
						$strSQL = "UPDATE product";
						$strSQL .=" SET product_picture = '".$picture."' WHERE p_id = '".$id."' ";
						$objQuery = mysqli_query($connection,$strSQL);
					}
				}
			}
		



//if($query || $objQuery){
	header("location: backend.php");
//}
?>