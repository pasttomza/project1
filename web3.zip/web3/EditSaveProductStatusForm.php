<?php 
include_once "Config.php";
$name = $_POST['product_status_name'];
$id = $_POST['product_status_id'];

$sql = "
		UPDATE product_status SET 
			product_status_name = '".$name."'
		WHERE product_status_id = '".$id."'
";
$query = mysqli_query($connection,$sql);
if($query){
	header("location: ProductStatusIndex.php");
}
?>