<?php 
include_once "Config.php";
		
		
		$bname     = $_POST['bank_name'];
		$bnamebank = $_POST['bank_namebank'];
		$blastname = $_POST['bank_lastname'];
		$bbranch   = $_POST['bank_branch'];
		$bnumber   = $_POST['bank_number'];
		$btype     = $_POST['bank_type'];
		
		$id        = $_POST['bank_id'];

$sql = "
		UPDATE bankaccount SET 
			
			
			bank_name       = '".$bname."',
			bank_namebank   = '".$bnamebank."',
			bank_lastname   = '".$blastname."',
			bank_branch     = '".$bbranch."',
			bank_number     = '".$bnumber."',
			bank_type       = '".$btype."'
		
		WHERE bank_id = '".$id."'
";
$query = mysqli_query($connection,$sql);

	if($_FILES['bank_picture']['name'] != ""){
				$name = $_FILES['bank_picture']['name'];
				$tmp = $_FILES['bank_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['bank_picture']['name'])){
							$oldImg = $_FILES['bank_picture']['name'];

							if(file_exists("images/$oldImg")){
								@unlink("images/$oldImg");
							}
						}
					

						$picture = $name;
						$strSQL = "UPDATE bankaccount";
						$strSQL .=" SET bank_picture = '".$picture."' WHERE bank_id = '".$id."' ";
						$objQuery = mysqli_query($connection,$strSQL);
					}
				}
			}


//if($query || $objQuery){
	header("location: BankAccount.php");
//}
?>
		
