<?php 
include_once "Config.php";
		
		$fid       = $_POST['id_farmer'];
		$fname     = $_POST['farmer_name'];
		$flastname = $_POST['farmer_lastname'];
		$ftell     = $_POST['farmer_tell'];
		$faddress  = $_POST['farmer_address'];
		$fnamefarm = $_POST['farmer_namefarm'];
		
		$id        = $_POST['farmer_id'];

$sql = "
		UPDATE farmer SET 
			
			id_farmer         = '".$fid."',
			farmer_name       = '".$fname."',
			farmer_lastname   = '".$flastname."',
			farmer_tell       = '".$ftell."',
			farmer_address    = '".$faddress."',
			farmer_namefarm   = '".$fnamefarm."'
		
		WHERE farmer_id = '".$id."'
";
$query = mysqli_query($connection,$sql);

	if($_FILES['farmer_picture']['name'] != ""){
				$name = $_FILES['farmer_picture']['name'];
				$tmp = $_FILES['farmer_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['farmer_picture']['name'])){
							$oldImg = $_FILES['farmer_picture']['name'];

							if(file_exists("images/$oldImg")){
								@unlink("images/$oldImg");
							}
						}
					

						$picture = $name;
						$strSQL = "UPDATE farmer";
						$strSQL .=" SET farmer_picture = '".$picture."' WHERE farmer_id = '".$id."' ";
						$objQuery = mysqli_query($connection,$strSQL);
					}
				}
			}


//if($query || $objQuery){
	header("location: ProfileFarmerIndex.php");
//}
?>
		
