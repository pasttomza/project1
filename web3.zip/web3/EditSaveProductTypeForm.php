<?php 
include_once "Config.php";
$name = $_POST['product_type_name'];
$id = $_POST['product_type_id'];

$sql = "
		UPDATE product_type SET 
			product_type_name = '".$name."'
		WHERE product_type_id = '".$id."'
";
$query = mysqli_query($connection,$sql);
if($query){
	header("location: ProductTypeIndex.php");
}
?>