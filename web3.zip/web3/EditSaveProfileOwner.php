<?php 
include_once "Config.php";
		

		$oname     = $_POST['owner_name'];
		$olastname = $_POST['owner_lastname'];
		$otell     = $_POST['owner_tell'];
		$oemail    = $_POST['owner_email'];
		$oaddress  = $_POST['owner_address'];
		$opassword = $_POST['password'];
		
		$id        = $_POST['owner_id'];

$sql = "
		UPDATE owner SET 
			
			owner_name      = '".$oname."',
			owner_lastname  = '".$olastname."',
			owner_tell      = '".$otell."',
			owner_email     = '".$oemail."',
			owner_address   = '".$oaddress."',
			password        = '".$opassword."'
		
		WHERE owner_id = '".$id."'
";
$query = mysqli_query($connection,$sql);

	if($_FILES['owner_picself']['name'] != ""){
				$name = $_FILES['owner_picself']['name'];
				$tmp = $_FILES['owner_picself']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['owner_picself']['name'])){
							$oldImg = $_FILES['owner_picself']['name'];

							if(file_exists("images/$oldImg")){
								@unlink("images/$oldImg");
							}
						}
					

						$picture = $name;
						$strSQL = "UPDATE owner";
						$strSQL .=" SET owner_picself = '".$picture."' WHERE owner_id = '".$id."' ";
						$objQuery = mysqli_query($connection,$strSQL);
					}
				}
			}


//if($query || $objQuery){
	header("location: ProfileOwner.php");
//}
?>
		
