<?php 
include_once "Config.php";
$name = $_POST['season_name'];
$id = $_POST['season_id'];

$sql = "
		UPDATE season SET 
			season_name = '".$name."'
		WHERE season_id = '".$id."'
";
$query = mysqli_query($connection,$sql);
if($query){
	header("location: ProductSeasonIndex.php");
}
?>