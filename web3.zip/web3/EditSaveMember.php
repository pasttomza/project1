<?php 
include_once "Config.php";
		

		$mname     = $_POST['member_name'];
		$mlastname = $_POST['member_lastname'];
		$mtell     = $_POST['member_tell'];
		$memail    = $_POST['member_email'];
		$maddress  = $_POST['member_address'];
		$musername = $_POST['member_username'];
		$mpassword = $_POST['member_password'];
		
		$id        = $_POST['member_id'];

$sql = "
		UPDATE member SET 
			
			member_name      = '".$mname."',
			member_lastname  = '".$mlastname."',
			member_tell      = '".$mtell."',
			member_email     = '".$memail."',
			member_address   = '".$maddress."',
			member_username  = '".$musername."',
			member_password  = '".$mpassword."'
		
		WHERE member_id = '".$id."'
";
$query = mysqli_query($connection,$sql);

	if($_FILES['member_picture']['name'] != ""){
				$name = $_FILES['member_picture']['name'];
				$tmp = $_FILES['member_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['member_picture']['name'])){
							$oldImg = $_FILES['member_picture']['name'];

							if(file_exists("images/$oldImg")){
								@unlink("images/$oldImg");
							}
						}
					

						$picture = $name;
						$strSQL = "UPDATE member";
						$strSQL .=" SET member_picture = '".$picture."' WHERE member_id = '".$id."' ";
						$objQuery = mysqli_query($connection,$strSQL);
					}
				}
			}


//if($query || $objQuery){
	header("location: Show_member.php");
//}
?>
		
