<?php 
include_once "Config.php";
		

		$sname     = $_POST['shop_name'];
		$sdes      = $_POST['shop_description'];
		$stell     = $_POST['shop_telephone'];
		$semail    = $_POST['shop_email'];
		$saddress  = $_POST['shop_address'];
	
		
		$id        = $_POST['shop_id'];

$sql = "
		UPDATE shop SET 
			
			shop_name         = '".$sname."',
			shop_description  = '".$sdes."',
			shop_telephone    = '".$stell."',
			shop_email        = '".$semail."',
			shop_address      = '".$saddress."'
		
		
		WHERE shop_id = '".$id."'
";
$query = mysqli_query($connection,$sql);

	if($_FILES['shop_picture']['name'] != ""){
				$name = $_FILES['shop_picture']['name'];
				$tmp = $_FILES['shop_picture']['tmp_name'];

				$ext = explode(".",$name);
				$ext = $ext[count($ext) - 1];

				$ext = strtolower($ext);

				if($ext == "png" || $ext == "jpg"){
					$name = microtime();
					$name = str_replace(" ", "", $name);
					$name = str_replace("0.", "", $name);
					$name = $name.".".$ext;

					if(move_uploaded_file($tmp, "images/$name")){
						//remove old images
						if(!empty($_FILES['shop_picture']['name'])){
							$oldImg = $_FILES['shop_picture']['name'];

							if(file_exists("images/$oldImg")){
								@unlink("images/$oldImg");
							}
						}
					

						$picture = $name;
						$strSQL = "UPDATE shop";
						$strSQL .=" SET shop_picture = '".$picture."' WHERE shop_id = '".$id."' ";
						$objQuery = mysqli_query($connection,$strSQL);
					}
				}
			}


//if($query || $objQuery){
	header("location: ProfileShop.php");
//}
?>
		
