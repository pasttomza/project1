<?php 
include_once "Config.php";
$name = $_POST['unit_name'];
$id = $_POST['unit_id'];

$sql = "
		UPDATE unit SET 
			unit_name = '".$name."'
		WHERE unit_id = '".$id."'
";
$query = mysqli_query($connection,$sql);
if($query){
	header("location: UnitIndex.php");
}
?>